import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';

void main() => runApp(const RealCutApp());

const blue = Color(0xFF1769FF);
const dark = Color(0xFF101216);
const panel = Color(0xFF1B2029);

class RealCutApp extends StatelessWidget {
  const RealCutApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'REAL CUT',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: dark,
        colorScheme: ColorScheme.fromSeed(seedColor: blue, brightness: Brightness.dark),
        useMaterial3: true,
      ),
      home: const EditorHome(),
    );
  }
}

class EditorHome extends StatefulWidget {
  const EditorHome({super.key});
  @override
  State<EditorHome> createState() => _EditorHomeState();
}

class _EditorHomeState extends State<EditorHome> {
  final picker = ImagePicker();
  VideoPlayerController? controller;
  bool loading = false;

  Future<void> pickVideo() async {
    final file = await picker.pickVideo(source: ImageSource.gallery);
    if (file == null || !mounted) return;
    setState(() => loading = true);
    await controller?.dispose();
    final next = VideoPlayerController.file(File(file.path));
    try {
      await next.initialize();
      if (!mounted) {
        await next.dispose();
        return;
      }
      setState(() {
        controller = next;
        loading = false;
      });
    } catch (_) {
      await next.dispose();
      if (mounted) setState(() => loading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Video open nahi hua. Dusra video try karein.')),
        );
      }
    }
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = controller;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: blue,
        title: const Text('REAL CUT', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2)),
        actions: [
          TextButton(
            onPressed: c == null ? null : () => _comingSoon('Export'),
            child: const Text('EXPORT', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('Make every frame count.', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            const Text('Simple editing. Pro-style look.', style: TextStyle(color: Colors.white70)),
            const SizedBox(height: 18),
            Container(
              height: 300,
              decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(22),
                border: Border.all(color: blue.withOpacity(.45))),
              clipBehavior: Clip.antiAlias,
              child: loading
                  ? const Center(child: CircularProgressIndicator())
                  : c == null
                      ? InkWell(
                          onTap: pickVideo,
                          child: const Center(child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.video_library_outlined, size: 64, color: blue),
                              SizedBox(height: 14),
                              Text('Choose a video', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                              SizedBox(height: 6),
                              Text('Tap here to open your gallery', style: TextStyle(color: Colors.white70)),
                            ],
                          )),
                        )
                      : Stack(
                          alignment: Alignment.center,
                          children: [
                            AspectRatio(
                              aspectRatio: c.value.aspectRatio > 0 ? c.value.aspectRatio : 9 / 16,
                              child: VideoPlayer(c),
                            ),
                            IconButton.filled(
                              onPressed: () => setState(() => c.value.isPlaying ? c.pause() : c.play()),
                              iconSize: 34,
                              icon: Icon(c.value.isPlaying ? Icons.pause : Icons.play_arrow),
                            ),
                          ],
                        ),
            ),
            const SizedBox(height: 16),
            Row(children: [
              Expanded(child: _action(Icons.video_library, 'Import video', pickVideo)),
              const SizedBox(width: 10),
              Expanded(child: _action(Icons.music_note, 'Music', () => _comingSoon('Music'))),
            ]),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: _action(Icons.content_cut, 'Trim / Cut', () => _comingSoon('Trim / Cut'))),
              const SizedBox(width: 10),
              Expanded(child: _action(Icons.text_fields, 'Add text', () => _comingSoon('Add text'))),
            ]),
            const SizedBox(height: 10),
            Row(children: [
              Expanded(child: _action(Icons.auto_awesome, 'Filters', () => _comingSoon('Filters'))),
              const SizedBox(width: 10),
              Expanded(child: _action(Icons.speed, 'Speed', () => _comingSoon('Speed'))),
            ]),
            const SizedBox(height: 18),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)),
              child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Icon(Icons.info_outline, color: blue),
                SizedBox(width: 10),
                Expanded(child: Text(
                  'Starter build: video gallery se import aur preview kaam karta hai. Trim, music, text, filters aur final export ke liye agle development step mein editing engine jodna hoga.',
                  style: TextStyle(color: Colors.white70, height: 1.4),
                )),
              ]),
            ),
          ],
        ),
      ),
    );
  }

  Widget _action(IconData icon, String label, VoidCallback onTap) => SizedBox(
    height: 60,
    child: FilledButton.tonal(
      style: FilledButton.styleFrom(backgroundColor: panel, foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
      onPressed: onTap,
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, color: blue, size: 21),
        const SizedBox(height: 3),
        Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
      ]),
    ),
  );

  void _comingSoon(String feature) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$feature feature next build mein add hoga.')),
    );
  }
}

