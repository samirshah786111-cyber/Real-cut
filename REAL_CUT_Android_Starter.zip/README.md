# REAL CUT — Android starter project

This is a Flutter starter project for the REAL CUT video editor, using a blue/black theme.

## Current working features
- Android app UI branded REAL CUT
- Select a video from the phone gallery
- Preview and play/pause the selected video

## Not implemented yet
Trim/cut export, audio/music mixing, text overlays, filters, speed controls, transitions, and final rendered video export. Buttons for these show a placeholder notice; they are not functional editing tools yet.

## Build APK
1. Install Flutter SDK and Android Studio on a computer.
2. Create a Flutter project with `flutter create real_cut`.
3. Replace the generated `pubspec.yaml` and `lib/main.dart` with the files in this archive.
4. Ensure Android app label/manifest uses the provided manifest snippet (merge it with Flutter's generated Android manifest rather than blindly replacing if your Flutter version differs).
5. Run:
   flutter pub get
   flutter run
6. Build a release APK:
   flutter build apk --release
   The APK will be at `build/app/outputs/flutter-apk/app-release.apk`.

This archive is source code, not a prebuilt APK. The Android build must be run in a Flutter/Android build environment.
